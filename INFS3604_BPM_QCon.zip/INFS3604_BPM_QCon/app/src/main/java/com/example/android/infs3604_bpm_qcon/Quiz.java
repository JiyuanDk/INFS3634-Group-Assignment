package com.example.android.infs3604_bpm_qcon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Quiz extends AppCompatActivity {
    private Button submit;
    private RadioGroup rg1;
    private RadioGroup rg2;
    private RadioGroup rg3;
    private RadioGroup rg4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        submit = findViewById(R.id.b_2);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Quiz.this, Feedback.class);
                startActivity(intent);
            }
        });

        rg1 = findViewById(R.id.rg_1);
        rg2 = findViewById(R.id.rg_2);
        rg3 = findViewById(R.id.rg_3);
        rg4 = findViewById(R.id.rg_4);

        rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb_4) {
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(Quiz.this, "Incorrect", Toast.LENGTH_LONG).show();

                }
            }
        });

        rg2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb_8) {
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(Quiz.this, "Incorrect", Toast.LENGTH_LONG).show();

                }
            }
        });

        rg3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb_9) {
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(Quiz.this, "Incorrect", Toast.LENGTH_LONG).show();

                }
            }
        });

        rg4.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb_16) {
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(Quiz.this, "Incorrect", Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
